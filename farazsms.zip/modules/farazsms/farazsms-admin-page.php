<!-- The file is required for rendering Farazsms Settings page powered by React. -->
<div id="farazsms-admin-page">
    <h2>Loading...</h2>
</div>
<div id="farazsms-portal"></div>