import { createContext } from "react";

const StateContext = createContext();

export default StateContext;
